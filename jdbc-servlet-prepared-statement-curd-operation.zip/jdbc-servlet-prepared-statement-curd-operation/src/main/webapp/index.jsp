
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Employee Management System</title>

<style>

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
}

/* Professional Gradient Background */
body {
    min-height: 100vh;
    background: linear-gradient(145deg, #1e2b4f 0%, #2a3f6e 50%, #1e3a5f 100%);
    display: flex;
    flex-direction: column;
    position: relative;
    overflow-x: hidden;
}

/* Decorative Elements */
body::before {
    content: '';
    position: absolute;
    top: -50%;
    right: -20%;
    width: 80%;
    height: 80%;
    background: radial-gradient(circle, rgba(255,255,255,0.1) 0%, rgba(255,255,255,0) 70%);
    border-radius: 50%;
    z-index: 0;
}

body::after {
    content: '';
    position: absolute;
    bottom: -30%;
    left: -10%;
    width: 60%;
    height: 60%;
    background: radial-gradient(circle, rgba(255,255,255,0.08) 0%, rgba(255,255,255,0) 70%);
    border-radius: 50%;
    z-index: 0;
}

/* Header */
header {
    background: rgba(255, 255, 255, 0.1);
    backdrop-filter: blur(10px);
    -webkit-backdrop-filter: blur(10px);
    color: white;
    padding: 25px 30px;
    text-align: center;
    font-size: 32px;
    font-weight: 600;
    letter-spacing: 0.5px;
    border-bottom: 1px solid rgba(255, 255, 255, 0.15);
    position: relative;
    z-index: 1;
    text-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
    box-shadow: 0 4px 20px rgba(0, 0, 0, 0.2);
}

/* Container */
.container {
    width: 90%;
    max-width: 1200px;
    margin: 80px auto;
    text-align: center;
    position: relative;
    z-index: 1;
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
    align-items: stretch;
    gap: 30px;
}

/* Cards Layout - More Professional Design */
.card {
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    width: 260px;
    margin: 0;
    padding: 40px 20px;
    border-radius: 20px;
    color: white;
    font-size: 22px;
    font-weight: 600;
    transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
    box-shadow: 0 15px 35px rgba(0, 0, 0, 0.3);
    position: relative;
    overflow: hidden;
    border: 1px solid rgba(255, 255, 255, 0.2);
    backdrop-filter: blur(5px);
    min-height: 180px;
}

/* Card Icons - Using CSS pseudo-elements for icons */
.card::before {
    font-family: 'Segoe UI', 'Arial', sans-serif;
    font-size: 48px;
    margin-bottom: 15px;
    opacity: 0.9;
    text-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);
}

/* Specific Icons for Each Card */
.add::before {
    content: "➕";
    font-size: 42px;
}

.view::before {
    content: "👥";
    font-size: 48px;
}

.update::before {
    content: "✏️";
    font-size: 44px;
}

.delete::before {
    content: "🗑️";
    font-size: 44px;
}

/* Card Inner Shadow Effect */
.card::after {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: linear-gradient(135deg, rgba(255,255,255,0.2) 0%, rgba(255,255,255,0) 50%);
    pointer-events: none;
}

.card a {
    text-decoration: none;
    color: white;
    position: relative;
    z-index: 1;
    text-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
    letter-spacing: 0.3px;
    margin-top: 5px;
}

/* More Sophisticated Card Gradients */
.add {
    background: linear-gradient(145deg, #0A66C2, #004182);
    background: linear-gradient(145deg, #1e4b8a, #0f2b4f);
}

.view {
    background: linear-gradient(145deg, #1e8a5e, #0d5e40);
    background: linear-gradient(145deg, #1f7b5a, #0e4f3a);
}

.update {
    background: linear-gradient(145deg, #b45f06, #7e4104);
    background: linear-gradient(145deg, #a0550a, #6b3807);
}

.delete {
    background: linear-gradient(145deg, #a1222a, #6b151b);
    background: linear-gradient(145deg, #8e1f26, #5c1419);
}

/* Enhanced Hover Effect */
.card:hover {
    transform: translateY(-15px) scale(1.03);
    box-shadow: 0 30px 50px rgba(0, 0, 0, 0.4);
    border: 1px solid rgba(255, 255, 255, 0.4);
}

/* Card Glow Effect on Hover */
.card:hover::before {
    transform: scale(1.1);
    transition: transform 0.3s ease;
}

/* Footer */
footer {
    margin-top: auto;
    background: rgba(0, 0, 0, 0.3);
    backdrop-filter: blur(5px);
    -webkit-backdrop-filter: blur(5px);
    color: rgba(255, 255, 255, 0.9);
    text-align: center;
    padding: 18px;
    font-size: 15px;
    letter-spacing: 0.3px;
    border-top: 1px solid rgba(255, 255, 255, 0.15);
    position: relative;
    z-index: 1;
    font-weight: 400;
}

/* Responsive Design */
@media (max-width: 768px) {
    header {
        font-size: 26px;
        padding: 20px;
    }
    
    .container {
        width: 95%;
        gap: 20px;
        margin: 40px auto;
    }
    
    .card {
        width: 220px;
        padding: 30px 15px;
        font-size: 20px;
        min-height: 160px;
    }
    
    .card::before {
        font-size: 38px;
    }
}

@media (max-width: 480px) {
    .card {
        width: 100%;
        max-width: 280px;
    }
    
    header {
        font-size: 22px;
        padding: 18px;
    }
}

/* Smooth Loading Animation */
@keyframes fadeInUp {
    from {
        opacity: 0;
        transform: translateY(30px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

.container .card {
    animation: fadeInUp 0.6s ease-out forwards;
    opacity: 0;
}

.container .card:nth-child(1) { animation-delay: 0.1s; }
.container .card:nth-child(2) { animation-delay: 0.2s; }
.container .card:nth-child(3) { animation-delay: 0.3s; }
.container .card:nth-child(4) { animation-delay: 0.4s; }

/* Focus Visible for Accessibility */
.card a:focus-visible {
    outline: 3px solid white;
    outline-offset: 4px;
    border-radius: 4px;
}

</style>

</head>
<body>

<header>
Employee Management System Dashboard
</header>

<div class="container">

<div class="card add">
<a href="addEmployee.jsp">Add Employee</a>
</div>

<div class="card view">
<a href="viewEmployees.jsp">Login Employees</a>
</div>

<div class="card update">
<a href="updateEmployee.jsp">Update Employee</a>
</div>

<div class="card delete">
<a href="deleteEmployee.jsp">Delete Employee</a>
</div>

</div>

<footer>
© 2026 Employee Management System
</footer>

</body>
</html>