<%@ page language="java" contentType="text/html; charset=ISO-8859-1" pageEncoding="ISO-8859-1"%>
<%@ page import="com.tcs.jdbc_servlet_prepared_statement_curd_operation.dao.EmployeeDao"%>
<%@ page import="java.util.List"%>
<%@ page import="com.tcs.jdbc_servlet_prepared_statement_curd_operation.dto.Employee" %>
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>display-page</title>
</head>
<body>

		<%
			HttpSession httpSession=request.getSession();
			Object object=httpSession.getAttribute("employeeSession");
			List<Employee> employees=
			new EmployeeDao().getAllEmployeeDao();
			
			if(object!=null){
		%>

	<button><a href="addEmployee.jsp">Add-Student</a></button>

		<h3>Display-Employee-Data</h3>
		
		<h3>total student present in table = <%=employees.size()%></h3>
		
		<table border="2">
			<tr>
				<th>ID:</th>
				<th>NAME:</th>
				<th>EMAIL:</th>
				<th>PHONE:</th>
				<th>DOB:</th>
				<th>DOJ:</th>
				<th colspan="2">ACTION:</th>
			</tr>
			
			
		<%for (Employee employee:employees) {%>
			
			<tr>
				<td><%=employee.getId()%></td>
				<td><%=employee.getName()%></td>
				<td><%=employee.getEmail()%></td>
				<td><%=employee.getPhone()%></td>
				<td><%=employee.getDob()%></td>
				<td><%=employee.getDoj()%></td>
				<td><a href="update.jsp?id=<%=employee.getId()%>">EDIT</a></td>
				<td><a href="delete?id=<%=employee.getId()%>">DELETE</a></td>
			</tr>
		
		<%}%>
			
			
		</table>
		
		<%}else{%>
		
			<%
			
			request.setAttribute("msg", "your session is expired please login...");
			
			RequestDispatcher dispatcher=
			request.getRequestDispatcher("login.jsp");
	
	        dispatcher.forward(request, response);
	        
			%>
		
		<%}%>
		
		<a href="logout">LOGOUT</a>
</body>
</html>