<%@ page language="java" contentType="text/html; charset=ISO-8859-1" pageEncoding="ISO-8859-1"%>
<%@ page import="com.tcs.jdbc_servlet_prepared_statement_curd_operation.dao.EmployeeDao"%>
<%@ page import="com.tcs.jdbc_servlet_prepared_statement_curd_operation.dto.Employee" %>
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Update-Page</title>

<style>

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family: Arial, Helvetica, sans-serif;
}

/* Background */
body{
    height:100vh;
    display:flex;
    justify-content:center;
    align-items:center;
    background: linear-gradient(135deg,#667eea,#764ba2);
}

/* Form Card */
.container{
    background:white;
    padding:40px;
    border-radius:10px;
    width:100%;
    max-width:420px;
    box-shadow:0 10px 25px rgba(0,0,0,0.2);
}

/* Title */
.container h2{
    text-align:center;
    margin-bottom:20px;
    color:#333;
}

/* Labels */
label{
    font-weight:bold;
    color:#444;
    font-size:14px;
}

/* Inputs */
input{
    width:100%;
    padding:10px;
    margin:6px 0 15px 0;
    border-radius:5px;
    border:1px solid #ccc;
    transition:0.3s;
}

/* Input Focus */
input:focus{
    border-color:#667eea;
    outline:none;
    box-shadow:0 0 5px rgba(102,126,234,0.5);
}

/* Button */
button{
    width:100%;
    padding:12px;
    border:none;
    border-radius:5px;
    background: linear-gradient(135deg,#667eea,#764ba2);
    color:white;
    font-size:16px;
    cursor:pointer;
    transition:0.3s;
}

/* Button Hover */
button:hover{
    opacity:0.9;
}

/* Responsive */
@media(max-width:480px){
    .container{
        padding:25px;
    }
}

</style>

</head>

<body>

<%
	int id=Integer.parseInt(request.getParameter("id"));

	Employee employee=new EmployeeDao().getEmployeeByIdDao(id);
     
%>

<div class="container">

<h2>Update-Employee-Details</h2>

<form action="employeeUpdate" method="post">

<label>EMPLOYEE ID</label>
<input type="number"  name="id" value="<%=employee.getId()%>" readonly="readonly">

<label>EMPLOYEE NAME</label>
<input type="text"  name="name" value="<%=employee.getName()%>">

<label>EMPLOYEE EMAIL</label>
<input type="email"  name="email" value="<%=employee.getEmail()%>">

<label>EMPLOYEE PASSWORD</label>
<input type="password"  name="psw" value="<%=employee.getPassword()%>">

<label>EMPLOYEE PHONE</label>
<input type="tel"  name="phone" value="<%=employee.getPhone()%>">

<label>EMPLOYEE DOJ</label>
<input type="date" name="doj" value="<%=employee.getDoj()%>">

<label>EMPLOYEE DOB</label>
<input type="date" name="dob" value="<%=employee.getDob()%>">

<button type="submit">Update</button>

</form>

</div>

</body>
</html>