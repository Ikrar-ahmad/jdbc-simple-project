package com.tcs.jdbc_servlet_prepared_statement_curd_operation_servlet.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;

import com.tcs.jdbc_servlet_prepared_statement_curd_operation.dao.EmployeeDao;
import com.tcs.jdbc_servlet_prepared_statement_curd_operation.dto.Employee;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class RegisterEmployeeController extends HttpServlet {

	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		resp.setContentType("text/html");
		
//		String id = req.getParameter("id");
		
	   int originalid = Integer.parseInt(req.getParameter("id"));
	   String name = req.getParameter("name");
	   String email = req.getParameter("email");
	   String password = req.getParameter("password");
	   long phone = Long.parseLong(req.getParameter("phone"));
	   LocalDate dob = LocalDate.parse(req.getParameter("dob"));
	   LocalDate doj = LocalDate.parse(req.getParameter("doj"));
	   
		Employee employee = new Employee();
		
		employee.setId(originalid);
		employee.setName(name);
		employee.setEmail(email);
		employee.setPassword(password);
		employee.setPhone(phone);
		employee.setDob(dob);
		employee.setDoj(doj);
		
		EmployeeDao dao = new EmployeeDao();
		
		Employee emp = dao.saveEmployeeDao(employee);
		
		 PrintWriter printWriter=resp.getWriter();
		  
		  if(emp!=null) {
//			  printWriter.write("you are registered");
			  printWriter.write("<html><body><h3 style='color:green'>you are registered</h3></body></html>");
			  System.out.println("data registered");
			  resp.sendRedirect("login.jsp");
		  }else {
//			  printWriter.write("something went wrong");
			  printWriter.write("<html><body><h3 style='color:red;'>something went wrong</h3></body></html>");
			  System.out.println("something went wrong");
		  }
		
		
		
//		System.out.println("id = "+originalid);
//		
//		System.out.println("register employee controller");
	}
}