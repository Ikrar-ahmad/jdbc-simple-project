package com.tcs.jdbc_servlet_prepared_statement_curd_operation_servlet.controller;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet(value = "/logout")
public class LogoutEmployeeController extends HttpServlet{

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		HttpSession httpSession=req.getSession();
		
		Object object = httpSession.getAttribute("employeeSession");
		
		if(object!=null) {
			httpSession.invalidate();
			req.setAttribute("msg", "you are logout successfully!!!!");
			req.getRequestDispatcher("login.jsp").forward(req, resp);
		}
		
	}
}
