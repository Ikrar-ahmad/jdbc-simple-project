package com.tcs.jdbc_servlet_prepared_statement_curd_operation_servlet.controller;

import java.io.IOException;
import java.io.PrintWriter;

import com.tcs.jdbc_servlet_prepared_statement_curd_operation.dao.EmployeeDao;
import com.tcs.jdbc_servlet_prepared_statement_curd_operation.dto.Employee;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

public class LoginEmployeeController extends HttpServlet {
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		String email = req.getParameter("email");
		
		String password = req.getParameter("password");
		
		System.out.println("email = "+email+" password = "+password);
		
		EmployeeDao dao = new EmployeeDao();
		
		Employee employee=dao.getEmployeeByEmailDao(email);
		
		PrintWriter printWriter = resp.getWriter();
		
		if(employee!=null) {
			
			if(employee.getPassword().equals(password)) {
				
				HttpSession httpSession=req.getSession();
				
				httpSession.setAttribute("employeeSession", employee.getEmail());
				
				httpSession.setMaxInactiveInterval(30);
				
				System.out.println("login success");
				
				RequestDispatcher dispatcher=
						req.getRequestDispatcher("display.jsp");
				
				dispatcher.forward(req, resp);
				
			}else {
				System.out.println("something went wrong check your password");
//				printWriter.write("<html><body><h4 style='color:red;'>Given Password is Incorrect</h4></body></html>");
//				
				req.setAttribute("msg", "something went wrong check your password");
				
				RequestDispatcher dispatcher=
						req.getRequestDispatcher("login.jsp");
				
				dispatcher.forward(req, resp);
				
//				resp.sendRedirect("login.jsp");
			}
			
		}else {
			
			System.out.println("something went wrong check your email");
			
			req.setAttribute("msg", "something went wrong check your email");
			
			
//			printWriter.write("<html><body><h4 style='color:red;'>Given Email is Incorrect</h4></body></html>");
			
			RequestDispatcher dispatcher=
					req.getRequestDispatcher("login.jsp");
			
			dispatcher.forward(req, resp);
		}
	}

}