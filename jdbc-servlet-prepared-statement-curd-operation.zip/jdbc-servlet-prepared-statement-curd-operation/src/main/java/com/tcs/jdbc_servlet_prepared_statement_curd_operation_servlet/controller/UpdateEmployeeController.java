package com.tcs.jdbc_servlet_prepared_statement_curd_operation_servlet.controller;

import java.io.IOException;
import java.time.LocalDate;

import com.tcs.jdbc_servlet_prepared_statement_curd_operation.dao.EmployeeDao;
import com.tcs.jdbc_servlet_prepared_statement_curd_operation.dto.Employee;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet(value = "/employeeUpdate")
public class UpdateEmployeeController extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		   int originalid = Integer.parseInt(req.getParameter("id"));
		   String name = req.getParameter("name");
		   String email = req.getParameter("email");
		   String password = req.getParameter("psw");
		   long phone = Long.parseLong(req.getParameter("phone"));
		   LocalDate doj = LocalDate.parse(req.getParameter("doj"));
		   LocalDate dob = LocalDate.parse(req.getParameter("dob"));
			
		  
			
		   Employee employee = new Employee();
		   
		   employee.setId(originalid);
		   employee.setName(name);
		   employee.setEmail(email);
		   employee.setPassword(password);
		   employee.setPhone(phone);
		   employee.setDob(dob);
		   employee.setDoj(doj);
		   
		   EmployeeDao dao = new EmployeeDao();
		   
		   
		   boolean b=dao.updateEmployeeByEmployeeIdDao(employee);
		   
		   if(b) {
			   System.out.println("updated employee"+employee);
			   resp.sendRedirect("display.jsp");
		   }
		
	}
}
