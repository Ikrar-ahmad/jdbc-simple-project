package com.tcs.jdbc_servlet_prepared_statement_curd_operation_servlet.controller;

import java.io.IOException;

import com.tcs.jdbc_servlet_prepared_statement_curd_operation.dao.EmployeeDao;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet(value = "/delete")
public class DeleteEmployeeController extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		int id=Integer.parseInt(req.getParameter("id"));
		
		boolean b=new EmployeeDao().deleteEmployeeByIdDao(id);
		
		if(b) {
			resp.sendRedirect("display.jsp");
			
			System.out.println("delete employee with id = ....."+id);
		}
		
		
	}
	
}
