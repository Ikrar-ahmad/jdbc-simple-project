package com.tcs.jdbc_servlet_prepared_statement_curd_operation.collection.practice;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.tcs.jdbc_servlet_prepared_statement_curd_operation.dto.Employee;

public class EmployeeCollectionExample {
	

		public static void main(String[] args) {
			
			Employee e1=new Employee();
			e1.setId(8899);
			e1.setName("Ramesh");
			e1.setEmail("ramesh@gmail.com");
			e1.setPassword("Ramesh#$123");
			e1.setPhone(987654390);
			e1.setDob(LocalDate.parse("2003-10-10"));
			e1.setDoj(LocalDate.parse("2026-06-10"));
			
			Employee e2=new Employee();
			
			e2.setId(8879);
			e2.setName("Ramesh");
			e2.setEmail("ramesh@gmail.com");
			e2.setPassword("Ramesh#$123");
			e2.setPhone(987654390);
			e2.setDob(LocalDate.parse("2003-10-10"));
			e2.setDoj(LocalDate.parse("2026-06-10"));
			
			
			Employee e3=new Employee();
			
			e3.setId(8499);
			e3.setName("Ramesh");
			e3.setEmail("ramesh@gmail.com");
			e3.setPassword("Ramesh#$123");
			e3.setPhone(987654390);
			e3.setDob(LocalDate.parse("2003-10-10"));
			e3.setDoj(LocalDate.parse("2026-06-10"));
			
			List<Employee> employees = new ArrayList<Employee>();
			employees.add(e1);
			employees.add(e2);
			employees.add(e3);
			
			for (Employee employee : employees) {
				System.out.println(employee);
			}
			
		}

}
