
package com.tcs.jdbc_servlet_prepared_statement_curd_operation.controller;

import java.time.LocalDate;

import com.tcs.jdbc_servlet_prepared_statement_curd_operation.dao.EmployeeDao;
import com.tcs.jdbc_servlet_prepared_statement_curd_operation.dto.Employee;

public class InsertEmployeeController {

    public static void main(String[] args) {

        EmployeeDao dao = new EmployeeDao();

        Employee employee = new Employee();

        employee.setId(3343);
        employee.setName("Ikrar khan");
        employee.setEmail("ikrarkhan@gmail.com");
        employee.setPassword("Ikrar7860");
        employee.setPhone(124567834545L);

        employee.setDob(LocalDate.parse("2001-10-27"));
        employee.setDoj(LocalDate.parse("2026-10-22"));

        Employee result = dao.saveEmployeeDao(employee);

        String msg = result != null
                ? "Data Stored Successfully ✅"
                : "Something Went Wrong ❌";

        System.out.println(msg);
    }
    
}


