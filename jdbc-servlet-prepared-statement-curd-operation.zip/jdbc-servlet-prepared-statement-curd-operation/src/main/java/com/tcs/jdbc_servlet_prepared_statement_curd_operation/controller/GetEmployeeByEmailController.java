package com.tcs.jdbc_servlet_prepared_statement_curd_operation.controller;

import com.tcs.jdbc_servlet_prepared_statement_curd_operation.dao.EmployeeDao;
import com.tcs.jdbc_servlet_prepared_statement_curd_operation.dto.Employee;

public class GetEmployeeByEmailController {
	
public static void main(String[] args) {
		
		Employee employee=new EmployeeDao().getEmployeeByEmailDao("ac90876@gmail.com");
	
		if(employee!=null) {
			System.out.println(employee);
		}else {
			System.out.println("something went wrong");
		}
	}
		

}
