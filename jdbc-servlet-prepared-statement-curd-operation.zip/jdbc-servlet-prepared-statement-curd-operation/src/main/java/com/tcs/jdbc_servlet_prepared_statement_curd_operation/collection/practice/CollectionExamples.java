package com.tcs.jdbc_servlet_prepared_statement_curd_operation.collection.practice;

import java.util.ArrayList;
import java.util.List;


public class CollectionExamples {
	
public static void main(String[] args) {
		
		List list = new ArrayList();
		
		list.add(9090);
		list.add(12345);
		list.add("Hemant");
		list.add(1678.90);
		
		System.out.println(list);
		System.out.println(list.size());
		
		boolean b=list.contains("Hemant");
		
		System.out.println(b);
		
		list.remove(0);
		
		System.out.println(list);
		
		
		List<Integer> integers = new ArrayList<Integer>();
		integers.add(2345);
		integers.add(7654);
		
		for (Integer integer : integers) {
			if(integer%2==0) {
				System.out.println(integer);
			}
		}
		
	}

}
