
package com.tcs.jdbc_servlet_prepared_statement_curd_operation.connection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import com.mysql.cj.jdbc.Driver;

public class JdbcEmployeeConnection {

    public static Connection createJdbcEmployeeConnection() {

    	try {
			//step-1 Register Driver
			Driver driver = new Driver();
			DriverManager.registerDriver(driver);
			
			//stpe-2 Create Connection
			String url = "jdbc:mysql://localhost:3306/jdbc-m17";
			String username = "root";
			String password = "ikrarkhan7860@#";
			
			return DriverManager.getConnection(url, username, password);
			
		} catch (SQLException e) {
			e.printStackTrace();
			
			return null;
		}
    }
}

