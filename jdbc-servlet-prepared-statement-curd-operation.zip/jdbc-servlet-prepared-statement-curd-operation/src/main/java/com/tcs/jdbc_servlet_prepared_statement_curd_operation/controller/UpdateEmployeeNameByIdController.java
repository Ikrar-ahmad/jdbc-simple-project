package com.tcs.jdbc_servlet_prepared_statement_curd_operation.controller;

import java.util.Scanner;

import com.tcs.jdbc_servlet_prepared_statement_curd_operation.dao.EmployeeDao;
import com.tcs.jdbc_servlet_prepared_statement_curd_operation.dto.Employee;

public class UpdateEmployeeNameByIdController {
	
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		
		System.out.println("eneter employee id to update employeename");
		int id = scanner.nextInt();
		
		System.out.println("eneter new name employee");
		
		String name = scanner.next();
		
		EmployeeDao dao = new EmployeeDao();
		
		boolean b= dao.updateEmployeeNameByEmployeeIdDao(name, id);
		
		//String msg = b?"update":"somthing went worg";
		
		//System.out.println(msg);
		
       if(b) {
			
			System.out.println("data updated");
			
			Employee employee=dao.getEmployeeByIdDao(id);
			
			System.out.println("updated employee is....");
			System.out.println(employee);
		}else {
			System.out.println("something went wrong or check with your empid");
		}
	}
		
		
	}

