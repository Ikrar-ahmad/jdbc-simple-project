package com.tcs.jdbc_servlet_prepared_statement_curd_operation.controller;

import java.util.List;

import com.tcs.jdbc_servlet_prepared_statement_curd_operation.dao.EmployeeDao;
import com.tcs.jdbc_servlet_prepared_statement_curd_operation.dto.Employee;

public class GetAllEmployeeController {
	
public static void main(String[] args) {
		
		List<Employee> employees=new EmployeeDao().getAllEmployeeDao();
		
		for (Employee employee : employees) {
			
			System.out.println(employee);
		}
	}

}
